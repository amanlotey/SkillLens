export const runtime = "nodejs";

export async function POST(req) {
  const { prompt = "Hello from server" } = await req.json();
  const HF_TOKEN = process.env.HF_TOKEN;
  const MODEL = process.env.HF_MODEL || "openai-community/gpt2";

  const r = await fetch(
    `https://api-inference.huggingface.co/models/${encodeURIComponent(MODEL)}?wait_for_model=true`,
    {
      method: "POST",
      headers: {
        Authorization: `Bearer ${HF_TOKEN}`,
        "Content-Type": "application/json",
        Accept: "application/json",
      },
      body: JSON.stringify({ inputs: prompt, parameters: { max_new_tokens: 30 } }),
    }
  );

  if (!r.ok) {
    const t = await r.text().catch(() => "");
    return Response.json({ error: "HF failed", status: r.status, details: t }, { status: r.status });
  }
  const json = await r.json();
  return Response.json(json);
}
