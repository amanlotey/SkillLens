export async function POST(req) {
  const prompt = "Say hello.";

  try {
    const hfRes = await fetch(
      "https://api-inference.huggingface.co/models/gpt2",
      {
        method: "POST",
        headers: {
          Authorization: "Bearer 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",
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ inputs: prompt }),
      }
    );

    if (!hfRes.ok) {
      const errText = await hfRes.text();
      console.error(`[HF ${hfRes.status}]`, errText);
      return Response.json(
        { error: "Hugging Face API failed", details: errText },
        { status: 500 }
      );
    }

    const data = await hfRes.json();
    return Response.json({ result: data });
  } catch (err) {
    console.error("Server Error:", err);
    return Response.json(
      { error: "Unexpected server error", details: err.message },
      { status: 500 }
    );
  }
}
