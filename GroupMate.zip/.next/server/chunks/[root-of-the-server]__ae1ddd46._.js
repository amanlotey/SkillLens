module.exports = {

"[project]/.next-internal/server/app/api/analyze/route/actions.js [app-rsc] (server actions loader, ecmascript)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
}}),
"[externals]/next/dist/compiled/next-server/app-route-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-route-turbo.runtime.dev.js, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-route-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-route-turbo.runtime.dev.js"));

module.exports = mod;
}}),
"[externals]/next/dist/compiled/@opentelemetry/api [external] (next/dist/compiled/@opentelemetry/api, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/compiled/@opentelemetry/api", () => require("next/dist/compiled/@opentelemetry/api"));

module.exports = mod;
}}),
"[externals]/next/dist/compiled/next-server/app-page-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-page-turbo.runtime.dev.js, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js"));

module.exports = mod;
}}),
"[externals]/next/dist/server/app-render/work-unit-async-storage.external.js [external] (next/dist/server/app-render/work-unit-async-storage.external.js, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/server/app-render/work-unit-async-storage.external.js", () => require("next/dist/server/app-render/work-unit-async-storage.external.js"));

module.exports = mod;
}}),
"[externals]/next/dist/server/app-render/work-async-storage.external.js [external] (next/dist/server/app-render/work-async-storage.external.js, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/server/app-render/work-async-storage.external.js", () => require("next/dist/server/app-render/work-async-storage.external.js"));

module.exports = mod;
}}),
"[project]/lib/formatAiResponse.js [app-route] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "formatAiResponse": (()=>formatAiResponse)
});
function formatAiResponse(rawText) {
    if (!rawText) {
        return {
            missingSkills: [],
            recommendedCourses: [],
            missingSkillsRawText: '',
            recommendedCoursesRawText: ''
        };
    }
    // Step 1: Trim everything before the first "Missing Skills:"
    const startIndex = rawText.indexOf('Missing Skills:');
    const trimmedText = startIndex >= 0 ? rawText.slice(startIndex) : rawText;
    // Step 2: Extract just the clean blocks (last match for each, in case duplicated)
    const allMissing = [
        ...trimmedText.matchAll(/Missing Skills:\s*([\s\S]*?)(?=\nRecommended Courses:|$)/gi)
    ];
    const allCourses = [
        ...trimmedText.matchAll(/Recommended Courses:\s*([\s\S]*?)(?=\n[A-Z]|$)/gi)
    ];
    const missingBlock = allMissing.at(-1)?.[1]?.trim() || '';
    const courseBlock = allCourses.at(-1)?.[1]?.trim() || '';
    const cleanSection = (block)=>block.split('\n').map((line)=>line.trim()).filter((line)=>line.length > 0 && !/^[-*]?\s*(Skill|Course)?\s*\d*[:\-]?\s*$/i.test(line) && !/^Missing Skills[:]?$/i.test(line) && !/^Recommended Courses[:]?$/i.test(line)).map((line)=>line.replace(/^[-*]?\s*(\d+\.\s*)?/, '').trim());
    const unique = (arr)=>[
            ...new Set(arr)
        ];
    return {
        missingSkills: unique(cleanSection(missingBlock)),
        recommendedCourses: unique(cleanSection(courseBlock)),
        missingSkillsRawText: `Missing Skills:\n${missingBlock}`,
        recommendedCoursesRawText: `Recommended Courses:\n${courseBlock}`
    };
}
}}),
"[project]/src/app/api/analyze/route.js [app-route] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "POST": (()=>POST)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$formatAiResponse$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/formatAiResponse.js [app-route] (ecmascript)");
;
async function POST(req) {
    const prompt = 'Say hello.';
    try {
        const hfRes = await fetch('https://api-inference.huggingface.co/models/bigscience/bloomz-560m', {
            method: 'POST',
            headers: {
                Authorization: 'hf_zWtAAToKLkSfPXgSDzdqShbG0mlbuCLnNn',
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                inputs: prompt
            })
        });
        if (!hfRes.ok) {
            const errText = await hfRes.text();
            console.error(`[HF ${hfRes.status}]`, errText);
            return Response.json({
                error: 'Hugging Face API failed',
                details: errText
            }, {
                status: 500
            });
        }
        const data = await hfRes.json();
        return Response.json({
            result: data
        });
    } catch (err) {
        console.error('Server Error:', err);
        return Response.json({
            error: 'Unexpected server error',
            details: err.message
        }, {
            status: 500
        });
    }
}
}}),

};

//# sourceMappingURL=%5Broot-of-the-server%5D__ae1ddd46._.js.map